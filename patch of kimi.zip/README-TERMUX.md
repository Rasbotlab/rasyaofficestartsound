# 🎵 Melodix OpenAL Patch — Termux (Android) Build Guide

## 📱 Persyaratan
- Android dengan Termux terinstall
- Minimal 2GB free storage
- Koneksi internet (untuk download dependency)

## 🚀 Cara Build di Termux

### 1. Install Termux
Download dari F-Droid (bukan Play Store):
https://f-droid.org/packages/com.termux/

### 2. Extract Package
```bash
cd /sdcard/Download  # atau folder tempat kamu extract
unzip melodix-termux-build.zip
cd melodix-termux-build
```

### 3. Download Original JAR
```bash
mkdir -p melodix-openal-gradle/original
cd melodix-openal-gradle/original

# Download original mod JAR
wget "https://cdn.modrinth.com/data/QF6HUctU/versions/tv03qDdN/melodix-1.0.0.jar?mr_download_reason=standalone&mr_game_version=26.1.2&mr_loader=fabric" -O melodix-1.0.0.jar

cd ../..
```

### 4. Run Build Script
```bash
bash setup-and-build.sh
```

Script ini akan:
1. Install OpenJDK 21 via `pkg`
2. Install Gradle via `pkg`
3. Build project
4. Patch JAR asli dengan class OpenAL
5. Output: `melodix-1.0.0-openal.jar`

### 5. Install ke Minecraft
```bash
cp melodix-1.0.0-openal.jar /sdcard/Android/data/<pojav-folder>/files/.minecraft/mods/
# Hapus JAR asli jika ada
```

## 🔧 Manual Build (Kalau Script Gagal)

```bash
# Install JDK
pkg install openjdk-21

# Verify
java -version  # Should show Java 21
javac -version # Should show javac 21

# Build
cd melodix-openal-gradle
./gradlew build

# JAR output: build/libs/melodix-openal-1.0.0.jar
# Then manually patch using instructions in README.md
```

## ⚠️ Catatan Penting

### Memory Limit
Termux memiliki memory limit. Build mungkin gagal dengan OOM (Out of Memory) error.
**Solusi:**
```bash
# Tambah swap
pkg install swapspace
# atau
termux-chroot  # untuk akses lebih banyak memory
```

### Gradle Daemon
Gradle daemon bisa memakan banyak memory.
**Solusi:**
```bash
./gradlew build --no-daemon
```

### Network Timeout
Download dependency mungkin timeout di koneksi lambat.
**Solusi:**
```bash
# Retry build beberapa kali
./gradlew build --retry
```

## 🐛 Troubleshooting

### "package com.mojang.blaze3d.audio does not exist"
→ Minecraft mappings belum di-download. Run `./gradlew genSources` dulu.

### "cannot find symbol: class AL10"
→ LWJGL OpenAL belum tersedia. Pastikan `fabric.mod.json` tidak memblokir LWJGL.

### "OutOfMemoryError"
→ Tutup aplikasi lain, atau build di PC lalu transfer ke Android.

## 📦 Alternatif: Build di PC

Kalau Termux terlalu terbatas, build di PC:
1. Download `melodix-openal-gradle.zip` (sama isinya)
2. Extract di PC dengan Java 21
3. Run `./gradlew build && ./build.sh`
4. Transfer `melodix-1.0.0-openal.jar` ke Android

## 📄 License
MIT License
