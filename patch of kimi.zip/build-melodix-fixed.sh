#!/data/data/com.termux/files/usr/bin/bash
# Melodix OpenAL Build Script for Termux (Fixed Version)
# Run this from /storage/emulated/0/Mods

set -e

echo "=== Melodix OpenAL Builder for Termux ==="
echo ""

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
echo "Script location: $SCRIPT_DIR"

# Find the gradle project directory
if [ -d "$SCRIPT_DIR/melodix-openal-gradle" ]; then
    PROJECT_DIR="$SCRIPT_DIR/melodix-openal-gradle"
elif [ -d "/storage/emulated/0/Mods/melodix-openal-gradle" ]; then
    PROJECT_DIR="/storage/emulated/0/Mods/melodix-openal-gradle"
else
    echo "ERROR: Folder melodix-openal-gradle tidak ditemukan!"
    echo "Pastikan folder melodix-openal-gradle ada di direktori yang sama dengan script ini."
    exit 1
fi

echo "Project directory: $PROJECT_DIR"
cd "$PROJECT_DIR"

# Step 1: Check/Download original JAR
echo ""
echo "[1/6] Checking original JAR..."
mkdir -p original

if [ ! -f "original/melodix-1.0.0.jar" ]; then
    echo "Downloading melodix-1.0.0.jar..."
    cd original
    wget -O melodix-1.0.0.jar "https://cdn.modrinth.com/data/QF6HUctU/versions/tv03qDdN/melodix-1.0.0.jar?mr_download_reason=standalone&mr_game_version=26.1.2&mr_loader=fabric" || {
        echo "ERROR: Download gagal!"
        echo "Download manual dari: https://modrinth.com/mod/melodix/version/tv03qDdN"
        echo "Taruh file di: $(pwd)/original/melodix-1.0.0.jar"
        exit 1
    }
    cd ..
fi

echo "  Original JAR ready ($(ls -lh original/melodix-1.0.0.jar 2>/dev/null | awk '{print $5}'))"

# Step 2: Install Java
echo ""
echo "[2/6] Installing OpenJDK 21..."
pkg install -y openjdk-21 || {
    echo "ERROR: Gagal install OpenJDK 21"
    exit 1
}

# Verify
java -version
javac -version

# Step 3: Install Gradle
echo ""
echo "[3/6] Installing Gradle..."
pkg install -y gradle || {
    echo "ERROR: Gagal install Gradle"
    exit 1
}

# Verify gradle
gradle --version

# Step 4: Build using gradle directly
echo ""
echo "[4/6] Building project with gradle..."
echo "Current directory: $(pwd)"
echo "Looking for build.gradle..."
ls -la build.gradle 2>/dev/null || echo "build.gradle not found in $(pwd)"

# Make sure we're in the project directory
cd "$PROJECT_DIR"
gradle build || {
    echo "ERROR: Build gagal!"
    echo "Coba run: cd $PROJECT_DIR && gradle build --stacktrace"
    exit 1
}

if [ ! -f "build/libs/melodix-openal-1.0.0.jar" ]; then
    echo "ERROR: JAR hasil build tidak ditemukan!"
    echo "Mencari di build/libs/:"
    ls -la build/libs/ 2>/dev/null || echo "Folder build/libs/ tidak ada"
    exit 1
fi

echo "  Build successful!"

# Step 5: Extract original and replace classes
echo ""
echo "[5/6] Patching JAR..."

# Extract original
mkdir -p build/original-extracted
rm -rf build/original-extracted/*
cd build/original-extracted
jar xf ../../original/melodix-1.0.0.jar
cd ../..

# Remove old javax.sound dependent classes
rm -f build/original-extracted/com/musicplayer/AudioEngine.class
rm -f build/original-extracted/com/musicplayer/AudioEngine\$PlaybackSlot.class
rm -f build/original-extracted/com/musicplayer/AudioEngine\$DuckStage.class
rm -f build/original-extracted/com/musicplayer/player/FullPcmDecoder.class
rm -f build/original-extracted/com/musicplayer/player/FullPcmDecoder\$Result.class
rm -f build/original-extracted/com/musicplayer/player/PcmStream.class

# Extract new OpenAL classes
mkdir -p build/new-classes
cd build/new-classes
jar xf ../libs/melodix-openal-1.0.0.jar com/musicplayer/AudioEngine.class
jar xf ../libs/melodix-openal-1.0.0.jar com/musicplayer/AudioEngine\$PlaybackSlot.class
jar xf ../libs/melodix-openal-1.0.0.jar com/musicplayer/AudioEngine\$DuckStage.class
jar xf ../libs/melodix-openal-1.0.0.jar com/musicplayer/player/FullPcmDecoder.class
jar xf ../libs/melodix-openal-1.0.0.jar com/musicplayer/player/FullPcmDecoder\$Result.class
jar xf ../libs/melodix-openal-1.0.0.jar com/musicplayer/player/PcmStream.class
jar xf ../libs/melodix-openal-1.0.0.jar com/musicplayer/player/OpenALAudioPlayer.class
cd ../..

# Copy new classes
cp -r build/new-classes/com build/original-extracted/

echo "  Classes replaced"

# Step 6: Repack
echo ""
echo "[6/6] Repacking JAR..."

# Update fabric.mod.json
cat > build/original-extracted/fabric.mod.json << 'EOF'
{
  "schemaVersion": 1,
  "id": "musicplayer",
  "version": "1.0.0-openal",
  "name": "Melodix Music Player (OpenAL Patch)",
  "description": "Melodix patched for Android/Pojav compatibility using OpenAL backend.",
  "authors": ["distelbus-svg (original)", "OpenAL Patch"],
  "license": "MIT",
  "environment": "client",
  "icon": "assets/musicplayer/icon.png",
  "entrypoints": {
    "client": [
      "com.musicplayer.MusicPlayerMod"
    ]
  },
  "mixins": [
    "musicplayer.mixins.json"
  ],
  "depends": {
    "fabricloader": ">=0.16.0",
    "minecraft": ">=1.21.2",
    "java": ">=21",
    "fabric-api": "*"
  }
}
EOF

# Remove old signatures
rm -f build/original-extracted/META-INF/*.SF
rm -f build/original-extracted/META-INF/*.RSA
rm -f build/original-extracted/META-INF/*.DSA

# Create new JAR
cd build/original-extracted
jar cvf ../../melodix-1.0.0-openal.jar .
cd ../..

echo ""
echo "========================================"
echo "BUILD SELESAI!"
echo "========================================"
echo ""
echo "Output: $PROJECT_DIR/melodix-1.0.0-openal.jar"
echo "Size: $(ls -lh $PROJECT_DIR/melodix-1.0.0-openal.jar 2>/dev/null | awk '{print $5}')"
echo ""
echo "Cara install:"
echo "  1. Copy file melodix-1.0.0-openal.jar ke folder mods Minecraft"
echo "  2. Hapus melodix-1.0.0.jar yang asli"
echo "  3. Launch Minecraft via Pojav/MJ Launcher"
echo ""
echo "Contoh copy:"
echo "  cp $PROJECT_DIR/melodix-1.0.0-openal.jar /sdcard/Android/data/net.kdt.pojavlaunch/files/.minecraft/mods/"
echo ""
echo "Mod ini sekarang pakai OpenAL (bukan javax.sound.sampled)"
echo "dan harusnya bisa jalan di Android!"
